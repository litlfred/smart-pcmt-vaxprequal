# PreQual NRA/Holder: Bulgarian Drug Agency (BDA) - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual NRA/Holder: Bulgarian Drug Agency (BDA)**

## Example Organization: PreQual NRA/Holder: Bulgarian Drug Agency (BDA)

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Organization.html)

Bulgarian Drug Agency (BDA) (Government) (https://extranet.who.int/prequal/api#0013X00003cPkgXQAS)

-------

| | |
| :--- | :--- |
| Active: | true |
| Type: | Government |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Holder0013X00003cPkgXQAS",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "identifier" : [{
    "system" : "https://extranet.who.int/prequal/api",
    "value" : "0013X00003cPkgXQAS"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "govt"
    }]
  }],
  "name" : "Bulgarian Drug Agency (BDA)"
}

```
