# PreQual Manufacturer: Bharat Biotech International Limited - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Manufacturer: Bharat Biotech International Limited**

## Example Organization: PreQual Manufacturer: Bharat Biotech International Limited

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Organization.html)

Bharat Biotech International Limited (Other) (https://extranet.who.int/prequal/api#0013X0000498p3cQAA)

-------

| | |
| :--- | :--- |
| Active: | true |
| Type: | Other |



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Manufacturer0013X0000498p3cQAA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "identifier" : [{
    "system" : "https://extranet.who.int/prequal/api",
    "value" : "0013X0000498p3cQAA"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "other"
    }]
  }],
  "name" : "Bharat Biotech International Limited"
}

```
