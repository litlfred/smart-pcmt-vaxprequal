# PreQual Document: Container Photo-pq_153_Rubella_10dose_SIIPL_vial%26ampoule_image_2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_153_Rubella_10dose_SIIPL_vial%26ampoule_image_2022**

## Example Binary: PreQual Document: Container Photo-pq_153_Rubella_10dose_SIIPL_vial%26ampoule_image_2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iKg9YAE"
  },
  "documentName": "Container Photo-pq_153_Rubella_10dose_SIIPL_vial%26ampoule_image_2022",
  "documentType": "Photo",
  "versionId": "068NN000005z40eYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
