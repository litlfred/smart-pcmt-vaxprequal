# PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-pq_184_185_bOPV_GSK_VPASR_Jun16 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-pq_184_185_bOPV_GSK_VPASR_Jun16**

## Example Binary: PreQual Document: VPSAR (Vaccine Public Summary Assessment Report)-pq_184_185_bOPV_GSK_VPASR_Jun16

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iNqtYAE"
  },
  "documentName": "VPSAR (Vaccine Public Summary Assessment Report)-pq_184_185_bOPV_GSK_VPASR_Jun16",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005z78AYAQ",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
