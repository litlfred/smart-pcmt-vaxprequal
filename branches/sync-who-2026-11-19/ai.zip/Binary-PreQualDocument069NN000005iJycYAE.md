# PreQual Document: Container Photo-pq_167_Rotateq_1dose_Merck_container_image_580 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_167_Rotateq_1dose_Merck_container_image_580**

## Example Binary: PreQual Document: Container Photo-pq_167_Rotateq_1dose_Merck_container_image_580

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iJycYAE"
  },
  "documentName": "Container Photo-pq_167_Rotateq_1dose_Merck_container_image_580",
  "documentType": "Photo",
  "versionId": "068NN000005z3HWYAY",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
