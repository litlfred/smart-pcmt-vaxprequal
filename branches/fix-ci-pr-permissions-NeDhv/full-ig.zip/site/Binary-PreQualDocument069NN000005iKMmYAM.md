# PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022**

## Binary: PreQual Document: Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iKMmYAM"
  },
  "documentName": "Package Insert-pq_138_139_140_141_MR_SII_PI-PAHO_2022",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005z3hIYAQ",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
