# PreQualDocument069NN000005iLQyYAM - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005iLQyYAM**

## Example Binary: PreQualDocument069NN000005iLQyYAM

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iLQyYAM"
  },
  "documentName": "pq_146_Measles%20_1dose_SII_%20vial%26ampoule_image-2022",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005z4jsYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
