# PreQualDocument069NN000005iJTxYAM - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005iJTxYAM**

## Example Binary: PreQualDocument069NN000005iJTxYAM

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iJTxYAM"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_137_TT_20dose_SII_container_image_VVM",
  "documentType": "Photo",
  "versionId": "068NN000005z2lFYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
