# PreQualSite0013X0000498p3ZQAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualSite0013X0000498p3ZQAQ**

## Example Binary: PreQualSite0013X0000498p3ZQAQ

This content is an example of the [WHO PreQual Site Detail](StructureDefinition-PreQualSiteDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail",
  "siteOrganizationId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p3ZQAQ"
  },
  "siteOrganizationName": "Sinovac Biotech Co. Ltd",
  "addressLine1": "No. 39 Shangdi Xi Rd.  Haidian District",
  "city": "Beijing",
  "country": "China",
  "postalCode": "100085",
  "siteStatus": "Accepted",
  "siteActivity": "FVPManufacture"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
