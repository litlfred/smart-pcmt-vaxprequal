# PreQualPackaginga3H3X000001VaaCUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaCUAS**

## Example Binary: PreQualPackaginga3H3X000001VaaCUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaCUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "27.84",
  "description": "Carton of 10 tubes [Dimensions: 12.8 x 8.7 x 2.5 cm]",
  "height": "8.7",
  "length": "12.8",
  "width": "2.5",
  "primaryContainers": "1"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
