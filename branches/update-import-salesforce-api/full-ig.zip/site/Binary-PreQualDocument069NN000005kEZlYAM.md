# PreQualDocument069NN000005kEZlYAM - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005kEZlYAM**

## Example Binary: PreQualDocument069NN000005kEZlYAM

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005kEZlYAM"
  },
  "documentName": "pq_271_JE_live_5doses_Chengdu_vials_image_580",
  "documentType": "PhotoMainImage",
  "versionId": "068NN0000060zG9YAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
