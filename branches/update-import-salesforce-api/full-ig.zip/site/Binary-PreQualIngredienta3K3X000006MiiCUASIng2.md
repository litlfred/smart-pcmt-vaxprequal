# PreQualIngredienta3K3X000006MiiCUASIng2 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualIngredienta3K3X000006MiiCUASIng2**

## Example Binary: PreQualIngredienta3K3X000006MiiCUASIng2

This content is an example of the [WHO PreQual Product Ingredient](StructureDefinition-PreQualProductIngredient.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductIngredient",
  "ingredientType": "VxFVP",
  "product": "a3K3X000006MiiCUAS",
  "productComponentType": "Active"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
