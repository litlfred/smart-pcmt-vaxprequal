# PreQualDocument069NN000005i48IYAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i48IYAQ**

## Example Binary: PreQualDocument069NN000005i48IYAQ

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i48IYAQ"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_64_OPV_20dose_Haffkine_vials_image_",
  "documentType": "Photo",
  "versionId": "068NN000005ynUQYAY",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
