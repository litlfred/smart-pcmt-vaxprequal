# PreQualDocument069NN000005i8GuYAI - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i8GuYAI**

## Example Binary: PreQualDocument069NN000005i8GuYAI

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i8GuYAI"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_126_DTP_10dose_SII_container_image_VVM",
  "documentType": "Photo",
  "versionId": "068NN000005yredYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
