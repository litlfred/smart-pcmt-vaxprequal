# PreQualDocument069NN000005i1VTYAY - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i1VTYAY**

## Example Binary: PreQualDocument069NN000005i1VTYAY

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i1VTYAY"
  },
  "documentName": "Container Photo-pq_74_BCG_10dose_BB-NCIPD_container_image_active",
  "documentType": "Photo",
  "versionId": "068NN000005ykpzYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
