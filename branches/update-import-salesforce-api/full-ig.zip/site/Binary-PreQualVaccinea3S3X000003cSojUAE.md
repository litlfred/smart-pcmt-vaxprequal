# PreQualVaccinea3S3X000003cSojUAE - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualVaccinea3S3X000003cSojUAE**

## Example Binary: PreQualVaccinea3S3X000003cSojUAE

This content is an example of the [WHO PreQual Vaccine](StructureDefinition-PreQualVaccine.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine",
  "vaccineId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSojUAE"
  },
  "fullName": "Diphtheria and tetanus vaccine (adsorbed)",
  "abbreviatedName": "DT"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
