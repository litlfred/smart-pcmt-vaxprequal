# PreQualSite0013X0000498p4ZQAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualSite0013X0000498p4ZQAQ**

## Example Binary: PreQualSite0013X0000498p4ZQAQ

This content is an example of the [WHO PreQual Site Detail](StructureDefinition-PreQualSiteDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail",
  "siteOrganizationId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p4ZQAQ"
  },
  "siteOrganizationName": "Japan BCG Laboratory (JBL)",
  "addressLine1": "1-5-21 Otsuka  Bunkyo-ku",
  "city": "Tokyo",
  "country": "Japan",
  "postalCode": "112-0012",
  "siteStatus": "Accepted",
  "siteActivity": "FVPManufacture"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
