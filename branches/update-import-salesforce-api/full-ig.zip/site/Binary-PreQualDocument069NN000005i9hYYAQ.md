# PreQualDocument069NN000005i9hYYAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i9hYYAQ**

## Example Binary: PreQualDocument069NN000005i9hYYAQ

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i9hYYAQ"
  },
  "documentName": "Container Photo-pq_79_DT_20dose_BB-NCIPD_carton_image",
  "documentType": "Photo",
  "versionId": "068NN000005yt3gYAA",
  "fileExtension": "png",
  "fileType": "PNG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
