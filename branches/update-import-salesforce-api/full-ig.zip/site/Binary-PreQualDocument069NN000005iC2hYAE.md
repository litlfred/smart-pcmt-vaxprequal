# PreQualDocument069NN000005iC2hYAE - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005iC2hYAE**

## Example Binary: PreQualDocument069NN000005iC2hYAE

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iC2hYAE"
  },
  "documentName": "Package Insert-pq_125_126_127_DTP_SII_PI-2020",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005yvNEYAY",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
