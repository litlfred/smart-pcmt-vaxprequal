# PreQualDocument069NN000005i5CfYAI - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i5CfYAI**

## Example Binary: PreQualDocument069NN000005i5CfYAI

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i5CfYAI"
  },
  "documentName": "Package Insert-pq_78_79_DT_BB-NCIPD_PI-2020",
  "documentType": "Photo",
  "versionId": "068NN000005yoYnYAI",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
