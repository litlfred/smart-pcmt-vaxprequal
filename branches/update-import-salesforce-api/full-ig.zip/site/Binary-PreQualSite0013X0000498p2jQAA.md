# PreQualSite0013X0000498p2jQAA - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualSite0013X0000498p2jQAA**

## Example Binary: PreQualSite0013X0000498p2jQAA

This content is an example of the [WHO PreQual Site Detail](StructureDefinition-PreQualSiteDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualSiteDetail",
  "siteOrganizationId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p2jQAA"
  },
  "siteOrganizationName": "Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.",
  "addressLine1": "BB-NCIPD Ltd.26 Yanko Sakazov Blvd.",
  "city": "Sofia",
  "country": "Bulgaria",
  "postalCode": "1504",
  "siteStatus": "Accepted",
  "siteActivity": "FVPManufacture"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
