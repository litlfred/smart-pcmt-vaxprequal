# PreQualPackaginga3H3X000001VaaNUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaNUAS**

## Example Binary: PreQualPackaginga3H3X000001VaaNUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaNUAS"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Active: Box containing 4 000 amps. (80 000 doses)[Dimensions: 61 x 76 x 43 cm]",
  "volume": "61 x 76 x 43 cm",
  "totalDoses": "80000",
  "totalContainers": "4000"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
