# PreQualPackaginga3HNN0000007wYk2AI - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3HNN0000007wYk2AI**

## Example Binary: PreQualPackaginga3HNN0000007wYk2AI

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3HNN0000007wYk2AI"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box containing 300 vials (600 doses). Dimensions: 31 x 19 x 9.3 cm",
  "volume": "31 x 19 x 9.3",
  "totalDoses": "600",
  "totalContainers": "300"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
