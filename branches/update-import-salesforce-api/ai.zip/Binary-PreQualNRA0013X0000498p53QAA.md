# PreQualNRA0013X0000498p53QAA - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualNRA0013X0000498p53QAA**

## Example Binary: PreQualNRA0013X0000498p53QAA

This content is an example of the [WHO PreQual NRA](StructureDefinition-PreQualNRA.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualNRA",
  "nraId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p53QAA"
  },
  "name": "Ministère de la Santé publique (DPM)",
  "country": "Senegal",
  "organizationReference": {
    "reference": "Organization/Holder0013X0000498p53QAA"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
