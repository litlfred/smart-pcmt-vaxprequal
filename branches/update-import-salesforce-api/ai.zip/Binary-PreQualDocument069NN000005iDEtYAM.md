# PreQualDocument069NN000005iDEtYAM - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005iDEtYAM**

## Example Binary: PreQualDocument069NN000005iDEtYAM

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iDEtYAM"
  },
  "documentName": "Package Insert-pq_138_139_140_141_MR_SII_PI-UNICEF_2022",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005ywb3YAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
