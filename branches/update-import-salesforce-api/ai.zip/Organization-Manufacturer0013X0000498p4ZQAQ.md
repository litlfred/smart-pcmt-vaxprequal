# Manufacturer0013X0000498p4ZQAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Manufacturer0013X0000498p4ZQAQ**

## Example Organization: Manufacturer0013X0000498p4ZQAQ

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/3.8.0/StructureDefinition-IHE.mCSD.Organization.html)

**identifier**: `https://extranet.who.int/prequal/api`/0013X0000498p4ZQAQ

**active**: true

**type**: Other

**name**: Japan BCG Laboratory (JBL)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Manufacturer0013X0000498p4ZQAQ",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "identifier" : [{
    "system" : "https://extranet.who.int/prequal/api",
    "value" : "0013X0000498p4ZQAQ"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "other"
    }]
  }],
  "name" : "Japan BCG Laboratory (JBL)"
}

```
