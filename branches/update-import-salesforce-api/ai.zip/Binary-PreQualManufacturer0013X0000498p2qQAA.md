# PreQualManufacturer0013X0000498p2qQAA - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualManufacturer0013X0000498p2qQAA**

## Example Binary: PreQualManufacturer0013X0000498p2qQAA

This content is an example of the [WHO PreQual Manufacturer](StructureDefinition-PreQualManufacturer.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer",
  "manufacturerId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p2qQAA"
  },
  "name": "Chengdu Institute of Biological Products Co. Ltd",
  "addressLine1": "Baojiang Bridge",
  "city": "Chengdu",
  "state": "Sichuan",
  "country": "China",
  "postalCode": "610063",
  "isoCountryCode": "CHN",
  "region": "WPRO",
  "organizationReference": {
    "reference": "Organization/Manufacturer0013X0000498p2qQAA"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
