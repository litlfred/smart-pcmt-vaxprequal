# WHO PreQualificaiton Vaccine VaccineTypes - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO PreQualificaiton Vaccine VaccineTypes**

## CodeSystem: WHO PreQualificaiton Vaccine VaccineTypes 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualVaccineType | *Version*:0.1.0 |
| Draft as of 2026-03-11 | *Computable Name*:PreQualVaccineType |

 
WHO PreQualificaiton Vaccine VaccineTypes 

 This Code system is referenced in the content logical definition of the following value sets: 

* [PreQualVaccineType](ValueSet-PreQualVaccineType.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "PreQualVaccineType",
  "url" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualVaccineType",
  "version" : "0.1.0",
  "name" : "PreQualVaccineType",
  "title" : "WHO PreQualificaiton Vaccine VaccineTypes",
  "status" : "draft",
  "date" : "2026-03-11T13:44:05+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "WHO PreQualificaiton Vaccine VaccineTypes",
  "content" : "complete",
  "count" : 17,
  "concept" : [{
    "code" : "BCG",
    "display" : "BCG"
  },
  {
    "code" : "DT",
    "display" : "DT"
  },
  {
    "code" : "DTwP",
    "display" : "DTwP"
  },
  {
    "code" : "HepA",
    "display" : "HepA"
  },
  {
    "code" : "HepB",
    "display" : "HepB"
  },
  {
    "code" : "JE",
    "display" : "JE"
  },
  {
    "code" : "LARV",
    "display" : "LARV"
  },
  {
    "code" : "M",
    "display" : "M"
  },
  {
    "code" : "MMR",
    "display" : "MMR"
  },
  {
    "code" : "MR",
    "display" : "MR"
  },
  {
    "code" : "Malaria",
    "display" : "Malaria"
  },
  {
    "code" : "TDV",
    "display" : "TDV"
  },
  {
    "code" : "TT",
    "display" : "TT"
  },
  {
    "code" : "YF",
    "display" : "YF"
  },
  {
    "code" : "bOPV",
    "display" : "bOPV"
  },
  {
    "code" : "dT",
    "display" : "dT"
  },
  {
    "code" : "tOPV",
    "display" : "tOPV"
  }]
}

```
