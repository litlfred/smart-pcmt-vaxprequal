# PreQualDocument069NN000005kJhVYAU - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005kJhVYAU**

## Example Binary: PreQualDocument069NN000005kJhVYAU

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005kJhVYAU"
  },
  "documentName": "Package Insert-pq_325_bOPV_1%263_20dose_BIBP_PI-2019",
  "documentType": "ProductInsert",
  "versionId": "068NN00000613wTYAQ",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
