# PreQualPackaginga3H3X000001VaaHUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaHUAS**

## Example Binary: PreQualPackaginga3H3X000001VaaHUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaHUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "0.0",
  "description": "50",
  "primaryContainers": "50"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
