# PreQualDocument069NN000005hwyuYAA - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005hwyuYAA**

## Example Binary: PreQualDocument069NN000005hwyuYAA

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hwyuYAA"
  },
  "documentName": "Package Insert-pq_69_HepB_1dose_LG_PI-2020_UNICEF",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005ygOFYAY",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
