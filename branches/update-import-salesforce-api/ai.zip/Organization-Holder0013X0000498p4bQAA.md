# Holder0013X0000498p4bQAA - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Holder0013X0000498p4bQAA**

## Example Organization: Holder0013X0000498p4bQAA

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/3.8.0/StructureDefinition-IHE.mCSD.Organization.html)

**identifier**: `https://extranet.who.int/prequal/api`/0013X0000498p4bQAA

**active**: true

**type**: Government

**name**: Agence nationale de sécurité du médicament et des produits de santé (ANSM)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Holder0013X0000498p4bQAA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "identifier" : [{
    "system" : "https://extranet.who.int/prequal/api",
    "value" : "0013X0000498p4bQAA"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "govt"
    }]
  }],
  "name" : "Agence nationale de sécurité du médicament et des produits de santé (ANSM)"
}

```
