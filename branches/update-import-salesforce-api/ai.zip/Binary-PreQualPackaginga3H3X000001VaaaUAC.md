# PreQualPackaginga3H3X000001VaaaUAC - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaaUAC**

## Example Binary: PreQualPackaginga3H3X000001VaaaUAC

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaaUAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box containing 192 cartons of 10 vials (19200 doses / 1920 vials)[Dimensions: 5.8 x 5.8 x 5.3 cm]",
  "volume": "5.8 x 5.8 x 5.3 cm",
  "totalDoses": "19200",
  "totalContainers": "1920"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
