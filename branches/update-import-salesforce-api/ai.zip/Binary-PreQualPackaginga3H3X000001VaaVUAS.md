# PreQualPackaginga3H3X000001VaaVUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaVUAS**

## Example Binary: PreQualPackaginga3H3X000001VaaVUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaVUAS"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "9.68",
  "description": "Carton of 100 vials (active) [Dimensions 17.8 x 14.7 x 3.7 cm]",
  "height": "14.7",
  "length": "17.8",
  "width": "3.7",
  "primaryContainers": "100"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
