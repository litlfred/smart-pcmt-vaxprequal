# PreQualPackaginga3H3X000001Vab0UAC - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001Vab0UAC**

## Example Binary: PreQualPackaginga3H3X000001Vab0UAC

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001Vab0UAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box containing 80 cartons of 5 vials (400 vials/2000 doses)[Dimensions: 393 x 147 x 207 cm]",
  "volume": "393 x 147 x 207 cm",
  "totalDoses": "2000",
  "totalContainers": "400"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
