# PreQualPackaginga3H3X000001VaaFUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaFUAS**

## Example Binary: PreQualPackaginga3H3X000001VaaFUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaFUAS"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 68 cartons (680 doses) [Dimensions: 34.2 x 25.1 x 43.1 cm]",
  "volume": "34.2 x 25.1 x 43.1 cm",
  "totalDoses": "680",
  "totalContainers": "680"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
