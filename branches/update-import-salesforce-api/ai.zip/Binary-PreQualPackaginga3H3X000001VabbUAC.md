# PreQualPackaginga3H3X000001VabbUAC - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VabbUAC**

## Example Binary: PreQualPackaginga3H3X000001VabbUAC

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VabbUAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "24 cartons of 50 vials (1200 vials/12000 doses) [Dimensions 60x48x41 cm]",
  "volume": "60 x 48 x 41 cm",
  "totalDoses": "12000",
  "totalContainers": "1200"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
