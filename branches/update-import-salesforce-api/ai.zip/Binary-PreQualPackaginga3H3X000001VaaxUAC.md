# PreQualPackaginga3H3X000001VaaxUAC - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VaaxUAC**

## Example Binary: PreQualPackaginga3H3X000001VaaxUAC

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaaxUAC"
  },
  "packagingType": "Secondary",
  "componentPacked": "ActiveVaccine",
  "coldChainVolume": "1.96",
  "description": "Carton of 10 vials (200 doses)  [Dimensions: 12.5 x 5.5 x 5.7 cm]",
  "height": "5.5",
  "length": "12.5",
  "width": "5.7",
  "primaryContainers": "10"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
