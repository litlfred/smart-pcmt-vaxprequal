# PreQualManufacturer0013X0000498p4ZQAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualManufacturer0013X0000498p4ZQAQ**

## Example Binary: PreQualManufacturer0013X0000498p4ZQAQ

This content is an example of the [WHO PreQual Manufacturer](StructureDefinition-PreQualManufacturer.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer",
  "manufacturerId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p4ZQAQ"
  },
  "name": "Japan BCG Laboratory (JBL)",
  "addressLine1": "1-5-21 Otsuka  Bunkyo-ku",
  "city": "Tokyo",
  "country": "Japan",
  "postalCode": "112-0012",
  "isoCountryCode": "JPN",
  "region": "WPRO",
  "website": "https://www.bcg.gr.jp/en/",
  "organizationReference": {
    "reference": "Organization/Manufacturer0013X0000498p4ZQAQ"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
