# PreQualDocument069NN000005i1aFYAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005i1aFYAQ**

## Example Binary: PreQualDocument069NN000005i1aFYAQ

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i1aFYAQ"
  },
  "documentName": "pq_76_TT_10dose_BB-NCIPD_container_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005ykumYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
