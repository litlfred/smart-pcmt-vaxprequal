# PreQualDocument069NN000005kGJsYAM - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005kGJsYAM**

## Example Binary: PreQualDocument069NN000005kGJsYAM

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005kGJsYAM"
  },
  "documentName": "Container Photo-pq_325_bOPV_1%263_20dose_BIBP_vial%26carton_image",
  "documentType": "Photo",
  "versionId": "068NN000006110FYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
