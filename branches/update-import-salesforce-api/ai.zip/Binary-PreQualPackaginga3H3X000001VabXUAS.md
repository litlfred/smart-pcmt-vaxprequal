# PreQualPackaginga3H3X000001VabXUAS - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualPackaginga3H3X000001VabXUAS**

## Example Binary: PreQualPackaginga3H3X000001VabXUAS

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VabXUAS"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 24 cartons of 50 vials (1200 vials/1200 doses) [Dimensions 60x48x41 cm]",
  "volume": "60 x 48 x 41 cm",
  "totalDoses": "1200",
  "totalContainers": "1200"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
