# PreQualDocument069NN000005hyzMYAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005hyzMYAQ**

## Example Binary: PreQualDocument069NN000005hyzMYAQ

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hyzMYAQ"
  },
  "documentName": "Container Photo-pq_77_TT_20dose_BB-NCIPD_container_image",
  "documentType": "Photo",
  "versionId": "068NN000005yiJsYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
