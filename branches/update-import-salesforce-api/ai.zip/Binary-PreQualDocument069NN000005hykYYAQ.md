# PreQualDocument069NN000005hykYYAQ - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDocument069NN000005hykYYAQ**

## Example Binary: PreQualDocument069NN000005hykYYAQ

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hykYYAQ"
  },
  "documentName": "pq_64_OPV_20dose_Haffkine_vials_image_580",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005yi56YAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
