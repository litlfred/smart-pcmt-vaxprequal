# PreQual Document: pq_80_Td_10dose_BB-NCIPD_container_image - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: pq_80_Td_10dose_BB-NCIPD_container_image**

## Example Binary: PreQual Document: pq_80_Td_10dose_BB-NCIPD_container_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i5UHYAY"
  },
  "documentName": "pq_80_Td_10dose_BB-NCIPD_container_image",
  "documentType": "PhotoMainImage",
  "versionId": "068NN000005yoqPYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
