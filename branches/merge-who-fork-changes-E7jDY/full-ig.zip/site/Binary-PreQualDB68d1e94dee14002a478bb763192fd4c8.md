# PreQualDB68d1e94dee14002a478bb763192fd4c8 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB68d1e94dee14002a478bb763192fd4c8**

## Binary: PreQualDB68d1e94dee14002a478bb763192fd4c8

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2023-02-14",
  "vaccineType": {
    "coding": [
      {
        "code": "Varicella",
        "display": "Varicella"
      }
    ]
  },
  "commercialName": "BARYCELA inj.",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "GC Biopharma Corp."
  },
  "responsibleNRA": {
    "text": "Ministry of Food and Drug Safety"
  },
  "index": {
    "value": "68d1e94dee14002a478bb763192fd4c8"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer0ac2fc7e2f3857eea1bd0d6fe3e1e432"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderd4e6bca678dea34fa256538a18200187"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/VaricellaProduct68d1e94dee14002a478bb763192fd4c8"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
