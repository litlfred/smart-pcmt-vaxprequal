# PreQualDB76f7fbefcf37814d2dbf2af5d784ad74 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB76f7fbefcf37814d2dbf2af5d784ad74**

## Binary: PreQualDB76f7fbefcf37814d2dbf2af5d784ad74

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2014-07-31",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusPertuss",
        "display": "Diphtheria-Tetanus-Pertussis (whole cell)"
      }
    ]
  },
  "commercialName": "None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  TRIPVAC",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Biological E. Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "76f7fbefcf37814d2dbf2af5d784ad74"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer54a4cbdf74f251158fb034e8f5e1ff5b"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusPertussProduct76f7fbefcf37814d2dbf2af5d784ad74"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
