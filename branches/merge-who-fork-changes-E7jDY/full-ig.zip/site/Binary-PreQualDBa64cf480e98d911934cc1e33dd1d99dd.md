# PreQualDBa64cf480e98d911934cc1e33dd1d99dd - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBa64cf480e98d911934cc1e33dd1d99dd**

## Binary: PreQualDBa64cf480e98d911934cc1e33dd1d99dd

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2019-09-24",
  "vaccineType": {
    "coding": [
      {
        "code": "MeaslesandRubella",
        "display": "Measles and Rubella"
      }
    ]
  },
  "commercialName": "Measles and Rubella Vaccine (Live) (Attenuated, Freeze Dried)",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "VialAmpoule",
        "display": "Vial + Ampoule"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "Biological E. Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "a64cf480e98d911934cc1e33dd1d99dd"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer54a4cbdf74f251158fb034e8f5e1ff5b"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/MeaslesandRubellaProducta64cf480e98d911934cc1e33dd1d99dd"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
