# PreQualf4c0952b7ac2caea70a5dd2b4e44a705 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualf4c0952b7ac2caea70a5dd2b4e44a705**

## Binary: PreQualf4c0952b7ac2caea70a5dd2b4e44a705

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holder9d7db6151eea8bf9048690e4b4504c90"
  },
  "validityPeriod": {
    "start": "2008-10-07"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/RotavirusProductf4c0952b7ac2caea70a5dd2b4e44a705"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
