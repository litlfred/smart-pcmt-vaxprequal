# PreQualDB4580ab03228ed6c70bb6c117b408f7e5 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB4580ab03228ed6c70bb6c117b408f7e5**

## Binary: PreQualDB4580ab03228ed6c70bb6c117b408f7e5

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2009-10-29",
  "vaccineType": {
    "coding": [
      {
        "code": "PolioVaccineOralOPVMonov",
        "display": "Polio Vaccine - Oral (OPV) Monovalent Type 1"
      }
    ]
  },
  "commercialName": "Polio Sabin Mono T1",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "GlaxoSmithKline Biologicals SA"
  },
  "responsibleNRA": {
    "text": "Federal Agency for Medicines and Health Products"
  },
  "index": {
    "value": "4580ab03228ed6c70bb6c117b408f7e5"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer214b31a3bf30c1816fab7b3f39ca25c9"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holdere0e3ed9114ce62feea705c24aceb2ee2"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PolioVaccineOralOPVMonovProduct4580ab03228ed6c70bb6c117b408f7e5"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
