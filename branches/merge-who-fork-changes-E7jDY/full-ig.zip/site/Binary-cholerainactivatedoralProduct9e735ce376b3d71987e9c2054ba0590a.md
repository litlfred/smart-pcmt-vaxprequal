# cholerainactivatedoralProduct9e735ce376b3d71987e9c2054ba0590a - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **cholerainactivatedoralProduct9e735ce376b3d71987e9c2054ba0590a**

## Binary: cholerainactivatedoralProduct9e735ce376b3d71987e9c2054ba0590a

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/Product",
  "status": "active",
  "name": [
    {
      "nameType": "official",
      "value": "Euvichol"
    }
  ],
  "manufacturer": {
    "reference": "Organization/Manufacturercb2d11a53a6d9504a6a08ab51b9aabe7"
  },
  "doseQuantity": {
    "value": 1,
    "code": "doses",
    "system": "http://unitsofmeasure.org"
  },
  "classification": [
    {
      "coding": [
        {
          "code": "cholerainactivatedoral"
        }
      ]
    }
  ],
  "unitOfUse": {
    "coding": [
      {
        "code": "doses"
      }
    ]
  },
  "dosageForm": {
    "coding": [
      {
        "code": "Vial"
      }
    ]
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
