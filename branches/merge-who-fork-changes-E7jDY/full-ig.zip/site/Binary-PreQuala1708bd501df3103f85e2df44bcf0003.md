# PreQuala1708bd501df3103f85e2df44bcf0003 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQuala1708bd501df3103f85e2df44bcf0003**

## Binary: PreQuala1708bd501df3103f85e2df44bcf0003

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holdere0e3ed9114ce62feea705c24aceb2ee2"
  },
  "validityPeriod": {
    "start": "2013-07-19"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisAHumanDiploidCeProducta1708bd501df3103f85e2df44bcf0003"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
