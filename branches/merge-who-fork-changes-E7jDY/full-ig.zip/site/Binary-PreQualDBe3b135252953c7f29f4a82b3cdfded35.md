# PreQualDBe3b135252953c7f29f4a82b3cdfded35 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBe3b135252953c7f29f4a82b3cdfded35**

## Binary: PreQualDBe3b135252953c7f29f4a82b3cdfded35

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2012-05-18",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusPertuss",
        "display": "Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b"
      }
    ]
  },
  "commercialName": "None used on labelling for supply through UN agencies.     Also marketed with labelled commercial name  ComBE Five (Liquid).",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Biological E. Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "e3b135252953c7f29f4a82b3cdfded35"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer54a4cbdf74f251158fb034e8f5e1ff5b"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusPertussProducte3b135252953c7f29f4a82b3cdfded35"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
