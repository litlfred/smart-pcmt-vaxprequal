# PreQualDBf22fcdfa611173d0afbce56d49867530 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBf22fcdfa611173d0afbce56d49867530**

## Binary: PreQualDBf22fcdfa611173d0afbce56d49867530

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2010-10-05",
  "vaccineType": {
    "coding": [
      {
        "code": "PolioVaccineOralOPVMonov",
        "display": "Polio Vaccine - Oral (OPV) Monovalent Type 3"
      }
    ]
  },
  "commercialName": "Polio Sabin Mono Three (oral)",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "GlaxoSmithKline Biologicals SA"
  },
  "responsibleNRA": {
    "text": "Federal Agency for Medicines and Health Products"
  },
  "index": {
    "value": "f22fcdfa611173d0afbce56d49867530"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer214b31a3bf30c1816fab7b3f39ca25c9"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holdere0e3ed9114ce62feea705c24aceb2ee2"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PolioVaccineOralOPVMonovProductf22fcdfa611173d0afbce56d49867530"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
