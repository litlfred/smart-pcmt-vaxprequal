# PreQualDB5b6b854e1885d59887a4eea0f4bd7a0c - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB5b6b854e1885d59887a4eea0f4bd7a0c**

## Binary: PreQualDB5b6b854e1885d59887a4eea0f4bd7a0c

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "1995-04-04",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusreduced",
        "display": "Diphtheria-Tetanus (reduced antigen content)"
      }
    ]
  },
  "commercialName": "Diphtheria and Tetanus Vaccine Adsorbed for Adults and Adolescents",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "5b6b854e1885d59887a4eea0f4bd7a0c"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusreducedProduct5b6b854e1885d59887a4eea0f4bd7a0c"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
