# PreQualb2a3129f600781cc753b011290b09acb - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualb2a3129f600781cc753b011290b09acb**

## Binary: PreQualb2a3129f600781cc753b011290b09acb

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "2004-11-12"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisBProductb2a3129f600781cc753b011290b09acb"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
