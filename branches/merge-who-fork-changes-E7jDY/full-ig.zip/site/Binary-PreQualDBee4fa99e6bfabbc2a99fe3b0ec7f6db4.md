# PreQualDBee4fa99e6bfabbc2a99fe3b0ec7f6db4 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBee4fa99e6bfabbc2a99fe3b0ec7f6db4**

## Binary: PreQualDBee4fa99e6bfabbc2a99fe3b0ec7f6db4

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2003-05-29",
  "vaccineType": {
    "coding": [
      {
        "code": "BCG",
        "display": "BCG"
      }
    ]
  },
  "commercialName": "BCG Vaccine",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "ee4fa99e6bfabbc2a99fe3b0ec7f6db4"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/BCGProductee4fa99e6bfabbc2a99fe3b0ec7f6db4"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
