# PreQualDBa2f4a9e07cfeebbb99d5ae2e4cc0257f - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBa2f4a9e07cfeebbb99d5ae2e4cc0257f**

## Binary: PreQualDBa2f4a9e07cfeebbb99d5ae2e4cc0257f

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2019-11-12",
  "vaccineType": {
    "coding": [
      {
        "code": "EbolaZairerVSVGZEBOVGPli",
        "display": "Ebola Zaire (rVSV∆G-ZEBOV-GP, live attenuated)"
      }
    ]
  },
  "commercialName": "ERVEBO",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "Merck Sharp & Dohme LLC"
  },
  "responsibleNRA": {
    "text": "European Medicines Agency"
  },
  "index": {
    "value": "a2f4a9e07cfeebbb99d5ae2e4cc0257f"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer764b91fadf395103d4ce901372cc0882"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holder06fc63d243e39d8519007322a0fddc52"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/EbolaZairerVSVGZEBOVGPliProducta2f4a9e07cfeebbb99d5ae2e4cc0257f"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
