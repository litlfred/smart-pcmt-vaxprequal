# PreQualDBfa2cfb4dc7d79771ed47d86a3efc9167 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBfa2cfb4dc7d79771ed47d86a3efc9167**

## Binary: PreQualDBfa2cfb4dc7d79771ed47d86a3efc9167

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "1991-02-01",
  "vaccineType": {
    "coding": [
      {
        "code": "BCG",
        "display": "BCG"
      }
    ]
  },
  "commercialName": "BCG Vaccine",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Ampoule",
        "display": "Ampoule"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)"
  },
  "responsibleNRA": {
    "text": "Bulgarian Drug Agency"
  },
  "index": {
    "value": "fa2cfb4dc7d79771ed47d86a3efc9167"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer7e1075439f93207b76e283af4e5a96d5"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holder2249658a617cfcc38ca334756748dcd0"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/BCGProductfa2cfb4dc7d79771ed47d86a3efc9167"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
