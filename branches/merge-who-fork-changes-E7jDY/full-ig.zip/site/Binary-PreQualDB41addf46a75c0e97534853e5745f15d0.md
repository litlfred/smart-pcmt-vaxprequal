# PreQualDB41addf46a75c0e97534853e5745f15d0 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB41addf46a75c0e97534853e5745f15d0**

## Binary: PreQualDB41addf46a75c0e97534853e5745f15d0

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2010-06-23",
  "vaccineType": {
    "coding": [
      {
        "code": "MeningococcalAConjugate1",
        "display": "Meningococcal A Conjugate 10 µg"
      }
    ]
  },
  "commercialName": "Meningococcal A Conjugate MenAfriVac",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "VialAmpoule",
        "display": "Vial + Ampoule"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "41addf46a75c0e97534853e5745f15d0"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/MeningococcalAConjugate1Product41addf46a75c0e97534853e5745f15d0"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
