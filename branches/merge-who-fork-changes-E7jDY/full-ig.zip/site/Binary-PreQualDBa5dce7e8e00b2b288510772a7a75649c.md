# PreQualDBa5dce7e8e00b2b288510772a7a75649c - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBa5dce7e8e00b2b288510772a7a75649c**

## Binary: PreQualDBa5dce7e8e00b2b288510772a7a75649c

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2006-05-09",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanus",
        "display": "Diphtheria-Tetanus"
      }
    ]
  },
  "commercialName": "Diftet",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 20,
  "manufacturer": {
    "text": "BB- NCIPD Ltd. (Bul Bio-National Center of Infectious and Parasitic Diseases Ltd.)"
  },
  "responsibleNRA": {
    "text": "Bulgarian Drug Agency"
  },
  "index": {
    "value": "a5dce7e8e00b2b288510772a7a75649c"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer7e1075439f93207b76e283af4e5a96d5"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holder2249658a617cfcc38ca334756748dcd0"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusProducta5dce7e8e00b2b288510772a7a75649c"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
