# PreQualDBfea93261bf2f096ea48aed825522dc2d - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDBfea93261bf2f096ea48aed825522dc2d**

## Binary: PreQualDBfea93261bf2f096ea48aed825522dc2d

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2019-07-11",
  "vaccineType": {
    "coding": [
      {
        "code": "PolioVaccineInactivatedI",
        "display": "Polio Vaccine - Inactivated (IPV)"
      }
    ]
  },
  "commercialName": "Poliomyelitis Vaccine (Inactivated)",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "fea93261bf2f096ea48aed825522dc2d"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PolioVaccineInactivatedIProductfea93261bf2f096ea48aed825522dc2d"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
