# RotavirusliveattenuatedProduct5d0aee9435820780b60fc3f11ce1cfb0 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **RotavirusliveattenuatedProduct5d0aee9435820780b60fc3f11ce1cfb0**

## Binary: RotavirusliveattenuatedProduct5d0aee9435820780b60fc3f11ce1cfb0

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/Product",
  "status": "active",
  "name": [
    {
      "nameType": "official",
      "value": "ROTASIIL-Liquid"
    }
  ],
  "manufacturer": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "doseQuantity": {
    "value": 1,
    "code": "doses",
    "system": "http://unitsofmeasure.org"
  },
  "classification": [
    {
      "coding": [
        {
          "code": "Rotavirusliveattenuated"
        }
      ]
    }
  ],
  "unitOfUse": {
    "coding": [
      {
        "code": "doses"
      }
    ]
  },
  "dosageForm": {
    "coding": [
      {
        "code": "Vial"
      }
    ]
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
