# PreQual4df3a93ab495d85b3583d0cd1ae3d83e - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual4df3a93ab495d85b3583d0cd1ae3d83e**

## Binary: PreQual4df3a93ab495d85b3583d0cd1ae3d83e

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "2015-03-20"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PolioVaccineOralOPVTrivaProduct4df3a93ab495d85b3583d0cd1ae3d83e"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
