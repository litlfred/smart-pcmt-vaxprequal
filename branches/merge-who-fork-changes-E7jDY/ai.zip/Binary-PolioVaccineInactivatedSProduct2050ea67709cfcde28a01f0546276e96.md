# PolioVaccineInactivatedSProduct2050ea67709cfcde28a01f0546276e96 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PolioVaccineInactivatedSProduct2050ea67709cfcde28a01f0546276e96**

## Binary: PolioVaccineInactivatedSProduct2050ea67709cfcde28a01f0546276e96

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/Product",
  "status": "active",
  "name": [
    {
      "nameType": "official",
      "value": "Poliomyelitis Vaccine (Vero Cell), Inactivated, Sabin Strains"
    }
  ],
  "manufacturer": {
    "reference": "Organization/Manufacturer56d509b36258f1c3e037132496afb0cb"
  },
  "doseQuantity": {
    "value": 1,
    "code": "doses",
    "system": "http://unitsofmeasure.org"
  },
  "classification": [
    {
      "coding": [
        {
          "code": "PolioVaccineInactivatedS"
        }
      ]
    }
  ],
  "unitOfUse": {
    "coding": [
      {
        "code": "doses"
      }
    ]
  },
  "dosageForm": {
    "coding": [
      {
        "code": "Vial"
      }
    ]
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
