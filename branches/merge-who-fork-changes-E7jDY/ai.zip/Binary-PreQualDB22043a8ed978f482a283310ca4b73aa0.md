# PreQualDB22043a8ed978f482a283310ca4b73aa0 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB22043a8ed978f482a283310ca4b73aa0**

## Binary: PreQualDB22043a8ed978f482a283310ca4b73aa0

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "1993-02-15",
  "vaccineType": {
    "coding": [
      {
        "code": "Measles",
        "display": "Measles"
      }
    ]
  },
  "commercialName": "Measles Vaccine, Live, Attenuated",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "22043a8ed978f482a283310ca4b73aa0"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/MeaslesProduct22043a8ed978f482a283310ca4b73aa0"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
