# PreQualDB2329c9c335034cc9d169c85cb142f137 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB2329c9c335034cc9d169c85cb142f137**

## Binary: PreQualDB2329c9c335034cc9d169c85cb142f137

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2019-12-27",
  "vaccineType": {
    "coding": [
      {
        "code": "InfluenzaseasonalQuadriv",
        "display": "Influenza, seasonal (Quadrivalent)"
      }
    ]
  },
  "commercialName": "SKYCellflu Quadrivalent Multi inj.",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "SK Bioscience Co., Ltd."
  },
  "responsibleNRA": {
    "text": "Ministry of Food and Drug Safety"
  },
  "index": {
    "value": "2329c9c335034cc9d169c85cb142f137"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer00bfdffd8d8dbe60aabda0191bb814ec"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderd4e6bca678dea34fa256538a18200187"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/InfluenzaseasonalQuadrivProduct2329c9c335034cc9d169c85cb142f137"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
