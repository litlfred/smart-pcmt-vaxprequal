# PreQual6a7cb8b1df3d2ff48b3e61cf5924c482 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual6a7cb8b1df3d2ff48b3e61cf5924c482**

## Binary: PreQual6a7cb8b1df3d2ff48b3e61cf5924c482

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderd4e6bca678dea34fa256538a18200187"
  },
  "validityPeriod": {
    "start": "2010-05-11"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/InfluenzaPandemicH1N1Product6a7cb8b1df3d2ff48b3e61cf5924c482"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
