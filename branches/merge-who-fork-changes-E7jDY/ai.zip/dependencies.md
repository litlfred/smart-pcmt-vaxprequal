# Dependencies - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Home**](index.md)
* **Dependencies**

## Dependencies

The following standards and profiles are referenced in this implementation guide:

* Integrating the Healthcare Enterprise (IHE):
* The International Patient Summary (IPS):
* World Health Organization (WHO):

