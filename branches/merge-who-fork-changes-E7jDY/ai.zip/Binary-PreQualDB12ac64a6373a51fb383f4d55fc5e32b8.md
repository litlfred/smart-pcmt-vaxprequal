# PreQualDB12ac64a6373a51fb383f4d55fc5e32b8 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB12ac64a6373a51fb383f4d55fc5e32b8**

## Binary: PreQualDB12ac64a6373a51fb383f4d55fc5e32b8

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2025-01-16",
  "vaccineType": {
    "coding": [
      {
        "code": "HepatitisBPaediatric",
        "display": "Hepatitis B (Paediatric)"
      }
    ]
  },
  "commercialName": "BEVAC®",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "Vial",
        "display": "Vial"
      }
    ]
  },
  "numDoses": 10,
  "manufacturer": {
    "text": "Biological E. Limited"
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "12ac64a6373a51fb383f4d55fc5e32b8"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer54a4cbdf74f251158fb034e8f5e1ff5b"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisBPaediatricProduct12ac64a6373a51fb383f4d55fc5e32b8"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
