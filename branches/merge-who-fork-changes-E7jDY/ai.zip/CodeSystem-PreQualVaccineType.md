# WHO PreQualificaiton Vaccine VaccineTypes - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **WHO PreQualificaiton Vaccine VaccineTypes**

## CodeSystem: WHO PreQualificaiton Vaccine VaccineTypes 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualVaccineType | *Version*:0.2.0 |
| Draft as of 2026-03-23 | *Computable Name*:PreQualVaccineType |

 
WHO PreQualificaiton Vaccine VaccineTypes 

 This Code system is referenced in the content logical definition of the following value sets: 

* [PreQualVaccineType](ValueSet-PreQualVaccineType.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "PreQualVaccineType",
  "url" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualVaccineType",
  "version" : "0.2.0",
  "name" : "PreQualVaccineType",
  "title" : "WHO PreQualificaiton Vaccine VaccineTypes",
  "status" : "draft",
  "date" : "2026-03-23T16:52:24+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "WHO PreQualificaiton Vaccine VaccineTypes",
  "content" : "complete",
  "count" : 57,
  "concept" : [{
    "code" : "BCG",
    "display" : "BCG"
  },
  {
    "code" : "Covid19",
    "display" : "Covid-19"
  },
  {
    "code" : "DengueTetravalentliveattenuated",
    "display" : "Dengue Tetravalent (live, attenuated)"
  },
  {
    "code" : "DiphtheriaTetanus",
    "display" : "Diphtheria-Tetanus"
  },
  {
    "code" : "DiphtheriaTetanusreducedantigencontent",
    "display" : "Diphtheria-Tetanus (reduced antigen content)"
  },
  {
    "code" : "DiphtheriaTetanusPertussisacellular",
    "display" : "Diphtheria-Tetanus-Pertussis (acellular)"
  },
  {
    "code" : "DiphtheriaTetanusPertussisacellularHepatitisBHaemophilusinfluenzaetypebPolioInactivated",
    "display" : "Diphtheria-Tetanus-Pertussis (acellular)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)"
  },
  {
    "code" : "DiphtheriaTetanusPertussiswholecell",
    "display" : "Diphtheria-Tetanus-Pertussis (whole cell)"
  },
  {
    "code" : "DiphtheriaTetanusPertussiswholecellHaemophilusinfluenzaetypeb",
    "display" : "Diphtheria-Tetanus-Pertussis (whole cell)-Haemophilus influenzae type b"
  },
  {
    "code" : "DiphtheriaTetanusPertussiswholecellHepatitisBHaemophilusinfluenzaetypeb",
    "display" : "Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b"
  },
  {
    "code" : "DiphtheriaTetanusPertussiswholecellHepatitisBHaemophilusinfluenzaetypebPolioInactivated",
    "display" : "Diphtheria-Tetanus-Pertussis (whole cell)-Hepatitis B-Haemophilus influenzae type b-Polio (Inactivated)"
  },
  {
    "code" : "EbolaZairerVSVGZEBOVGPliveattenuated",
    "display" : "Ebola Zaire (rVSV∆G-ZEBOV-GP, live attenuated)"
  },
  {
    "code" : "EbolavaccineAd26ZEBOVGPrecombinant",
    "display" : "Ebola vaccine (Ad26.ZEBOV-GP [recombinant])"
  },
  {
    "code" : "EbolavaccineMVABNFilorecombinant",
    "display" : "Ebola vaccine (MVA-BN-Filo [recombinant])"
  },
  {
    "code" : "Haemophilusinfluenzaetypeb",
    "display" : "Haemophilus influenzae type b"
  },
  {
    "code" : "HepatitisAHumanDiploidCellInactivatedAdult",
    "display" : "Hepatitis A (Human Diploid Cell), Inactivated (Adult)"
  },
  {
    "code" : "HepatitisAHumanDiploidCellInactivatedPaediatric",
    "display" : "Hepatitis A (Human Diploid Cell), Inactivated (Paediatric)"
  },
  {
    "code" : "HepatitisB",
    "display" : "Hepatitis B"
  },
  {
    "code" : "HepatitisBPaediatric",
    "display" : "Hepatitis B (Paediatric)"
  },
  {
    "code" : "HumanPapillomavirusBivalent",
    "display" : "Human Papillomavirus (Bivalent)"
  },
  {
    "code" : "HumanPapillomavirusNinevalent",
    "display" : "Human Papillomavirus (Ninevalent)"
  },
  {
    "code" : "HumanPapillomavirusQuadrivalent",
    "display" : "Human Papillomavirus (Quadrivalent)"
  },
  {
    "code" : "InfluenzaPandemicH1N1",
    "display" : "Influenza, Pandemic (H1N1)"
  },
  {
    "code" : "InfluenzaPandemicH5N1",
    "display" : "Influenza, Pandemic (H5N1)"
  },
  {
    "code" : "InfluenzaseasonalQuadrivalent",
    "display" : "Influenza, seasonal (Quadrivalent)"
  },
  {
    "code" : "InfluenzaseasonalTrivalent",
    "display" : "Influenza, seasonal (Trivalent)"
  },
  {
    "code" : "JapaneseEncephalitisVaccineInactivated3µgPediatric",
    "display" : "Japanese Encephalitis Vaccine (Inactivated) (3µg Pediatric)"
  },
  {
    "code" : "JapaneseEncephalitisVaccineInactivated6µg",
    "display" : "Japanese Encephalitis Vaccine (Inactivated) 6µg"
  },
  {
    "code" : "JapaneseEncephalitisVaccineliveattenuated",
    "display" : "Japanese Encephalitis Vaccine (live, attenuated)"
  },
  {
    "code" : "Malaria",
    "display" : "Malaria"
  },
  {
    "code" : "Measles",
    "display" : "Measles"
  },
  {
    "code" : "MeaslesandRubella",
    "display" : "Measles and Rubella"
  },
  {
    "code" : "MeaslesMumpsandRubella",
    "display" : "Measles, Mumps and Rubella"
  },
  {
    "code" : "MenigococcalACYWXPolysaccharideconjugate",
    "display" : "Menigococcal ACYWX (Polysaccharide conjugate)"
  },
  {
    "code" : "MeningococcalAConjugate10µg",
    "display" : "Meningococcal A Conjugate 10 µg"
  },
  {
    "code" : "MeningococcalAConjugate5µg",
    "display" : "Meningococcal A Conjugate 5 µg"
  },
  {
    "code" : "MeningococcalACYW135conjugatevaccine",
    "display" : "Meningococcal ACYW-135 (conjugate vaccine)"
  },
  {
    "code" : "MeningococcalACYW135TetanusToxoidconjugatevaccine",
    "display" : "Meningococcal ACYW-135 Tetanus Toxoid (conjugate vaccine)"
  },
  {
    "code" : "Pneumococcalconjugate",
    "display" : "Pneumococcal (conjugate)"
  },
  {
    "code" : "PolioVaccineInactivatedIPV",
    "display" : "Polio Vaccine - Inactivated (IPV)"
  },
  {
    "code" : "PolioVaccineInactivatedSabinsIPV",
    "display" : "Polio Vaccine - Inactivated Sabin (sIPV)"
  },
  {
    "code" : "PolioVaccineNovelOralnOPVType2",
    "display" : "Polio Vaccine - Novel Oral (nOPV) Type 2"
  },
  {
    "code" : "PolioVaccineOralOPVBivalentTypes1and3",
    "display" : "Polio Vaccine - Oral (OPV) Bivalent Types 1 and 3"
  },
  {
    "code" : "PolioVaccineOralOPVMonovalentType1",
    "display" : "Polio Vaccine - Oral (OPV) Monovalent Type 1"
  },
  {
    "code" : "PolioVaccineOralOPVMonovalentType2",
    "display" : "Polio Vaccine - Oral (OPV) Monovalent Type 2"
  },
  {
    "code" : "PolioVaccineOralOPVMonovalentType3",
    "display" : "Polio Vaccine - Oral (OPV) Monovalent Type 3"
  },
  {
    "code" : "PolioVaccineOralOPVTrivalent",
    "display" : "Polio Vaccine - Oral (OPV) Trivalent"
  },
  {
    "code" : "Rabies",
    "display" : "Rabies"
  },
  {
    "code" : "Rotavirus",
    "display" : "Rotavirus"
  },
  {
    "code" : "Rotavirusliveattenuated",
    "display" : "Rotavirus (live, attenuated)"
  },
  {
    "code" : "Rubella",
    "display" : "Rubella"
  },
  {
    "code" : "SmallpoxandMpoxvaccineLiveModifiedVacciniaVirusAnkara",
    "display" : "Smallpox and Mpox vaccine (Live Modified Vaccinia Virus Ankara)"
  },
  {
    "code" : "TetanusToxoid",
    "display" : "Tetanus Toxoid"
  },
  {
    "code" : "TyphoidConjugate",
    "display" : "Typhoid (Conjugate)"
  },
  {
    "code" : "Varicella",
    "display" : "Varicella"
  },
  {
    "code" : "YellowFever",
    "display" : "Yellow Fever"
  },
  {
    "code" : "cholerainactivatedoral",
    "display" : "cholera: inactivated oral"
  }]
}

```
