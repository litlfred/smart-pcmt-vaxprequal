# PreQual0269fa56eaf4988d90c519518ec6282e - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual0269fa56eaf4988d90c519518ec6282e**

## Binary: PreQual0269fa56eaf4988d90c519518ec6282e

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "1993-02-15"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/MeaslesProduct0269fa56eaf4988d90c519518ec6282e"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
