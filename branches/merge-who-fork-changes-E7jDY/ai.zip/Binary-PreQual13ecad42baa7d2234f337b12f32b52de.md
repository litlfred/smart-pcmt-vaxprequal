# PreQual13ecad42baa7d2234f337b12f32b52de - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual13ecad42baa7d2234f337b12f32b52de**

## Binary: PreQual13ecad42baa7d2234f337b12f32b52de

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holder9d7db6151eea8bf9048690e4b4504c90"
  },
  "validityPeriod": {
    "start": "2010-01-28"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/InfluenzaPandemicH1N1Product13ecad42baa7d2234f337b12f32b52de"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
