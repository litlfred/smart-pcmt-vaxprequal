# PreQual953ab5cac67cbb23eeab9e794501209d - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual953ab5cac67cbb23eeab9e794501209d**

## Binary: PreQual953ab5cac67cbb23eeab9e794501209d

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderd4e6bca678dea34fa256538a18200187"
  },
  "validityPeriod": {
    "start": "1996-11-22"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/HepatitisBProduct953ab5cac67cbb23eeab9e794501209d"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
