# PreQualDB2029c7c29c39910766a76fc788115bbc - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQualDB2029c7c29c39910766a76fc788115bbc**

## Binary: PreQualDB2029c7c29c39910766a76fc788115bbc

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDBwithIds",
  "dateOfPrequal": "2010-06-23",
  "vaccineType": {
    "coding": [
      {
        "code": "DiphtheriaTetanusPertuss",
        "display": "Diphtheria-Tetanus-Pertussis (whole cell)-Haemophilus influenzae type b"
      }
    ]
  },
  "commercialName": "Diphtheria, Tetanus, Pertussis and Haemophilus influenzae type b Conjugate Vaccine",
  "presentation": {
    "coding": [
      {
        "system": "https://extranet.who.int/prequal/vaccines/prequalified-vaccines",
        "code": "VialAmpoule",
        "display": "Vial + Ampoule"
      }
    ]
  },
  "numDoses": 1,
  "manufacturer": {
    "text": "Serum Institute of India Pvt. Ltd."
  },
  "responsibleNRA": {
    "text": "Central Drugs Standard Control Organization"
  },
  "index": {
    "value": "2029c7c29c39910766a76fc788115bbc"
  },
  "manufacturerReference": {
    "reference": "Organization/Manufacturer35b3de1add41b53c8e37ce338f2ba545"
  },
  "responsibleNRAReference": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "productReference": {
    "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/DiphtheriaTetanusPertussProduct2029c7c29c39910766a76fc788115bbc"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
