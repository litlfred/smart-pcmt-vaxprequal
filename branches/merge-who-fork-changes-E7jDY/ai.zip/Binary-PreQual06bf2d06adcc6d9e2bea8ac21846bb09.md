# PreQual06bf2d06adcc6d9e2bea8ac21846bb09 - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual06bf2d06adcc6d9e2bea8ac21846bb09**

## Binary: PreQual06bf2d06adcc6d9e2bea8ac21846bb09

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "2014-10-22"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/PolioVaccineOralOPVBivalProduct06bf2d06adcc6d9e2bea8ac21846bb09"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
