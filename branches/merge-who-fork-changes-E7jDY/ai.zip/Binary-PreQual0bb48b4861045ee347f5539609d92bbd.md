# PreQual0bb48b4861045ee347f5539609d92bbd - SMART Product Dataset for Prequalified Vaccines v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual0bb48b4861045ee347f5539609d92bbd**

## Binary: PreQual0bb48b4861045ee347f5539609d92bbd

```

{
  "resourceType": "http://smart.who.int/pcmt/StructureDefinition/ProductAuthorization",
  "status": "active",
  "type": "prequal",
  "jurisdiction": [
    {
      "coding": [
        {
          "display": "WHO"
        }
      ]
    }
  ],
  "holder": {
    "reference": "Organization/Holderf79f23b4c5122fd96b2c87cc385157fc"
  },
  "validityPeriod": {
    "start": "2006-09-01"
  },
  "product": [
    {
      "reference": "http://smart.who.int/pcmt/StructureDefinition/Product/RubellaProduct0bb48b4861045ee347f5539609d92bbd"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
