# PreQual Vaccine: Measles, mumps, rubella combined vaccine (live, attenuated) - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Vaccine: Measles, mumps, rubella combined vaccine (live, attenuated)**

## Example Binary: PreQual Vaccine: Measles, mumps, rubella combined vaccine (live, attenuated)

This content is an example of the [WHO PreQual Vaccine](StructureDefinition-PreQualVaccine.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine",
  "vaccineId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSpaUAE"
  },
  "fullName": "Measles, mumps, rubella combined vaccine (live, attenuated)",
  "abbreviatedName": "MMR"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
