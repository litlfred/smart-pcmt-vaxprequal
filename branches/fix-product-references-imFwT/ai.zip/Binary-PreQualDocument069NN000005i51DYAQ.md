# PreQual Document: Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image**

## Example Binary: PreQual Document: Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i51DYAQ"
  },
  "documentName": "Container Photo-pq_78_DT_10dose_BB-NCIPD_carton_image",
  "documentType": "Photo",
  "versionId": "068NN000005yoNLYAY",
  "fileExtension": "png",
  "fileType": "PNG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
