# PreQual Vaccine: Recombinant malaria vaccine - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Vaccine: Recombinant malaria vaccine**

## Example Binary: PreQual Vaccine: Recombinant malaria vaccine

This content is an example of the [WHO PreQual Vaccine](StructureDefinition-PreQualVaccine.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine",
  "vaccineId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSpnUAE"
  },
  "fullName": "Recombinant malaria vaccine",
  "abbreviatedName": "Malaria"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
