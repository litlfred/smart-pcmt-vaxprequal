# PreQual Document: Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510**

## Example Binary: PreQual Document: Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hpfqYAA"
  },
  "documentName": "Container Photo-pq_62_MMR_1dose_GSK_vial%2Bampl_image_510",
  "documentType": "Photo",
  "versionId": "068NN000005yZ0MYAU",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
