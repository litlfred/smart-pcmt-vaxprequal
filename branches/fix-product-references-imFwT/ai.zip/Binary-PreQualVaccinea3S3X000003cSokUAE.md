# PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content) - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content)**

## Example Binary: PreQual Vaccine: Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content)

This content is an example of the [WHO PreQual Vaccine](StructureDefinition-PreQualVaccine.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualVaccine",
  "vaccineId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3S3X000003cSokUAE"
  },
  "fullName": "Diphtheria and tetanus vaccine (adsorbed, reduced diphtheria antigen content)",
  "abbreviatedName": "dT"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
