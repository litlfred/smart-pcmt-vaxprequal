# PreQual Document: Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580**

## Example Binary: PreQual Document: Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iLDxYAM"
  },
  "documentName": "Container Photo-pq_137_TT_20dose_SII_continer_image_VVM_580",
  "documentType": "Photo",
  "versionId": "068NN000005z4WrYAI",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
