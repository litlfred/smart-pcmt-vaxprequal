# PreQual Packaging: Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm] - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm]**

## Example Binary: PreQual Packaging: Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VabZUAS"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 36 cartons of 50 ampoules (1800 ampoules/1800 doses) [Dimensions 60x48x41 cm]",
  "volume": "60 x 48 x 41 cm",
  "totalDoses": "1800",
  "totalContainers": "1800"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
