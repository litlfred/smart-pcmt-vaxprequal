# PreQual Packaging: Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm] - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm]**

## Example Binary: PreQual Packaging: Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm]

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VaapUAC"
  },
  "packagingType": "Tertiary",
  "componentPacked": "ActiveVaccine",
  "description": "Box of 20 wrapped cartons containing 10 boxes of 3 vials each (600 vials/12000 doses)[Dimensions: 46 x 29.5 x 14 cm]",
  "volume": "46 x 29.5 x 14 cm",
  "totalDoses": "12000",
  "totalContainers": "600"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
