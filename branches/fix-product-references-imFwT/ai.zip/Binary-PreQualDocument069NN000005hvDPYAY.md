# PreQual Document: Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image**

## Example Binary: PreQual Document: Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hvDPYAY"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_62_MMR_1dose_GSK_vial%2Bampl_image",
  "documentType": "Photo",
  "versionId": "068NN000005yebBYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
