# PreQual Manufacturer: Serum Institute of India - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Manufacturer: Serum Institute of India**

## Example Binary: PreQual Manufacturer: Serum Institute of India

This content is an example of the [WHO PreQual Manufacturer](StructureDefinition-PreQualManufacturer.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer",
  "manufacturerId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X00003cPkzfQAC"
  },
  "name": "Serum Institute of India",
  "addressLine1": "SERUM BIO-PHARMA PARK SEZ UNIT-1, 212/2 Off Soli Poonawala Road, Hadaspar",
  "city": "Pune",
  "state": "Maharashtra",
  "country": "India",
  "postalCode": "411 028",
  "isoCountryCode": "IND",
  "region": "SEARO",
  "website": "http://www.seruminstitute.com/",
  "organizationReference": {
    "reference": "Organization/Manufacturer0013X00003cPkzfQAC"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
