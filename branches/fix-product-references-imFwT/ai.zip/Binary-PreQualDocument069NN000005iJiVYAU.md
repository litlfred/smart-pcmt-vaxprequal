# PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022**

## Example Binary: PreQual Document: Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iJiVYAU"
  },
  "documentName": "Package Insert-pq_142_143_144_145_MMR_SIIPL_PI_UNICEF-2022",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005z2znYAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
