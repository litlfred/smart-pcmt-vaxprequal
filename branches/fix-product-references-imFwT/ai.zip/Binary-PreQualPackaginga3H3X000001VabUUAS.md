# PreQual Packaging: ShippingContainer - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Packaging: ShippingContainer**

## Example Binary: PreQual Packaging: ShippingContainer

This content is an example of the [WHO PreQual Product Packaging](StructureDefinition-PreQualProductPackaging.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualProductPackaging",
  "packagingId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "a3H3X000001VabUUAS"
  },
  "packagingType": "ShippingContainer",
  "componentPacked": "ActiveVaccine",
  "volume": "73 x 50 x 54 cm",
  "totalDoses": "5000",
  "totalContainers": "1000 vials"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
