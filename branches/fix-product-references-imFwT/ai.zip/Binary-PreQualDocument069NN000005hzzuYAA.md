# PreQual Document: General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet**

## Example Binary: PreQual Document: General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005hzzuYAA"
  },
  "documentName": "General-pq_63_Rotavirus_1dose_GSK_plastic_tube_instruction_sheet",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005yjKQYAY",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
