# PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO**

## Example Binary: PreQual Document: Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i4mdYAA"
  },
  "documentName": "Package Insert-pq_72_HepB_10doses_LG_PI-2020_PAHO",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005yo8lYAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
