# PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd**

## Example Organization: PreQual Manufacturer: Chengdu Institute of Biological Products Co. Ltd

Profile: [mCSD Organization](https://profiles.ihe.net/ITI/mCSD/3.8.0/StructureDefinition-IHE.mCSD.Organization.html)

**identifier**: `https://extranet.who.int/prequal/api`/0013X0000498p2qQAA

**active**: true

**type**: Other

**name**: Chengdu Institute of Biological Products Co. Ltd



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "Manufacturer0013X0000498p2qQAA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Organization"]
  },
  "identifier" : [{
    "system" : "https://extranet.who.int/prequal/api",
    "value" : "0013X0000498p2qQAA"
  }],
  "active" : true,
  "type" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
      "code" : "other"
    }]
  }],
  "name" : "Chengdu Institute of Biological Products Co. Ltd"
}

```
