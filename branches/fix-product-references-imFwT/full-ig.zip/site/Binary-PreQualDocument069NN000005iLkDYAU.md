# PreQual Document: Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022**

## Example Binary: PreQual Document: Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iLkDYAU"
  },
  "documentName": "Container Photo-pq_143_MMR_2dose_SII_vial%26diluent_image-2022",
  "documentType": "Photo",
  "versionId": "068NN000005z4ztYAA",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
