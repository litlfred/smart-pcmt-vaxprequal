# PreQual Document: Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image**

## Example Binary: PreQual Document: Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iAiPYAU"
  },
  "documentName": "Container Photo (Bigger Higher Resolution)-pq_125_DTP_1dose_SII_container_image",
  "documentType": "Photo",
  "versionId": "068NN000005yu4XYAQ",
  "fileExtension": "jpg",
  "fileType": "JPG"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
