# PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020 - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020**

## Example Binary: PreQual Document: Package Insert-pq_125_126_127_DTP_SII_PI-2020

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005iFy9YAE"
  },
  "documentName": "Package Insert-pq_125_126_127_DTP_SII_PI-2020",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005yzKHYAY",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
