# PreQual Manufacturer: Sinovac Biotech Co. Ltd - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Manufacturer: Sinovac Biotech Co. Ltd**

## Example Binary: PreQual Manufacturer: Sinovac Biotech Co. Ltd

This content is an example of the [WHO PreQual Manufacturer](StructureDefinition-PreQualManufacturer.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualManufacturer",
  "manufacturerId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "0013X0000498p3ZQAQ"
  },
  "name": "Sinovac Biotech Co. Ltd",
  "addressLine1": "No. 39 Shangdi Xi Rd.  Haidian District",
  "city": "Beijing",
  "country": "China",
  "postalCode": "100085",
  "isoCountryCode": "CHN",
  "region": "WPRO",
  "website": "http://www.sinovac.com/",
  "organizationReference": {
    "reference": "Organization/Manufacturer0013X0000498p3ZQAQ"
  }
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
