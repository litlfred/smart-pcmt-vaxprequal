# PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI - SMART Product Catalog v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI**

## Example Binary: PreQual Document: Package Insert-pq_65_66_67_YF_5dose_IPD_PI

This content is an example of the [WHO PreQual Document Detail](StructureDefinition-PreQualDocumentDetail.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://smart.who.int/pcmt-vaxprequal/StructureDefinition/PreQualDocumentDetail",
  "documentId": {
    "system": "https://extranet.who.int/prequal/api",
    "value": "069NN000005i4hmYAA"
  },
  "documentName": "Package Insert-pq_65_66_67_YF_5dose_IPD_PI",
  "documentType": "VaccineGeneralDocument",
  "versionId": "068NN000005yo3uYAA",
  "fileExtension": "pdf",
  "fileType": "PDF"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
